# Kit de reprodução — CVM/CASPAR via `pip install cvm-caspar`

Este directório tem o que a instalação por pip **não** traz: o corpus
experimental (`test_target/`, os dez pares da dissertação) e os dois scripts de
medição. Serve para uma máquina sem rede ou sem acesso ao GitHub; havendo rede,
uma linha faz tudo isto:

    curl -fsSL https://raw.githubusercontent.com/AFilipe-IT/cvm/master/scripts/reproducao/preparar.sh | bash

## Preparar a máquina

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install "cvm-caspar[api]==1.0.0"   # o extra [api] é o que o `caspar serve` precisa
caspar --version                       # caspar 1.0.0
caspar init                            # 514 regras, 12 alvos, 32 cadeias
```

Correr tudo a partir **deste** directório, para que `test_target/` e `ccss.db`
estejam no caminho relativo que os comandos usam.

## Verificar os dez pares

```bash
bash verificar.sh caspar      # esperado: 16 ok, 0 falhas
```

Verifica os dez pares vulneráveis contra os valores da dissertação, as
contrapartes endurecidas a 0.0, a agregação de pior caso e o manifesto
(`kb sha256:83b3ee01f415`). Qualquer falha significa que a versão instalada não
é a que a dissertação mede.

O par do nginx é verificado com `--service-version 1.24.0`. O `server_tokens`
expõe a versão do serviço e é amplificado quando essa versão tem exploits
públicos (5.0 na base, ×1.5 para a 1.24.0 → 7.5); sem fixar a versão, ela vem
do binário instalado no hospedeiro e o mesmo ficheiro dá 5.5 numa máquina sem
nginx. Fixá-la torna o resultado independente da máquina.

## Determinismo

```bash
cp ccss.db ccss_alt.db
python determinismo.py --runs 10 --db ccss.db --alt-db ccss_alt.db
```

Esperado: 2 ficheiros de base de dados, 10 configurações, 100 execuções,
`distinct digests per configuration : 1`. O `determinismo.py` fixa a versão do
nginx pela mesma razão, e é a versão autónoma de
`scripts/determinism_scan.py`: a mesma medição, sem depender do repositório.

## Relatórios e interfaces

```bash
caspar scan test_target/httpd.conf --report -f html -o reports
caspar serve      # http://127.0.0.1:2027/docs e http://127.0.0.1:2027/app/
```

O `-o reports` é obrigatório: sem ele o relatório é escrito na pasta `reports/`
*dentro* do `site-packages` do venv. A porta do `caspar serve` é a 2027.
